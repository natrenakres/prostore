# Section Intro

In this section, we'll be doing quite a few things. First, we're going to use a ShadCN drawer component fot the categories. We will have a button with an icon to the left of the logo in the header on main pages. This will open a drawer with the categories.

Then we're going to create the featured product banner. So if the product is marked as featured and has a banner, it will show up im this component. There will be arrow buttons to scroll through the banners on the homepage.

Next, we want to work on the search and filtering. We're going to create the search form in a component and put it in the header. Right now, the input is just hardcoded.

We'll create a search page for that form to submit to and we will get the search params like category, query and sort.

Then we need to take those values and use them in the action to apply the filters.

We also need to add all the filter links on to the search page. So they can click on a specific category, rating, price, etc.

We'll also implement sorting by price, rating and date.