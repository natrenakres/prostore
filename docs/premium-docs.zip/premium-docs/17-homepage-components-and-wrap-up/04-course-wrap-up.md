# Course Wrap Up

Alright, so if you made it this far, congratulations! This was not a small or easy project. I just want to talk a little bit about where to go from here.

So if you plan on getting a dev job or freelancing, if you understand most of this project, I would definitely say that you're ready. We hit on a lot of advanced and real-world concepts.

As far as this particular project goes, feel free to do what you want with it. It's open source. You can put it on your portfolo although I would suggest changing it up a bit. Maybe change up the style, products, categories and even add some features. I would like to keep going with this app as well. Like I said in the beginning, I plan on using this for my wife's art website in the future. Any additional features that I add, will be in this course. I already have the code for adding a Google login as well as a magik link login, which is a passwordless authentication method. So I may add those within the next few months.

But again, I want to congratulate you and wish you the best in your endevours of a software development. And I hope to see you in the next course!
